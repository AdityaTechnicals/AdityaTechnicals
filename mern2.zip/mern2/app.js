const express = require('express');
const app = express();
const dotenv = require('dotenv');
const cors = require('cors');
dotenv.config({ path: './config.env' })
require('./connection/conn')
const User= require('./models/Usschema');
const port = process.env.PORT;
app.use(express.json())
 app.use(cors())
 
 app.use(require('./routes/routs'))
 if(process.env.NODE_ENV == 'production'){
     app.use(express.static("vlients/build"));
 }
app.listen(port,()=>{
    console.log(`listening on port http://localhost:${port}`)
});
