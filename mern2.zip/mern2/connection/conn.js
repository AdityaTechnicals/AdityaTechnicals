const mongoose = require('mongoose');
const db = process.env.DB;
mongoose.connect(db).then(()=>{
    console.log('connected successfully with db')
}).catch(err => console.log(err))
