const mongoose = require('mongoose');
const validator = require('validator');
const userSchema = mongoose.Schema({
    name :{type:String,maxLength:100,minLength:2},
    phnum:{type:Number,maxLength:12,unique:true},
    email :{type:String,maxLength:100,unique:[true,"email is already present"],validate(value){
            if(!validator.isEmail(value)){throw new Error("Invalid email")}
    }},
    message:{type:String}
    
})
const User = new mongoose.model("User",userSchema)
module.exports = User;
